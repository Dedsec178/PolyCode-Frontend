import React, { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  DSA_CPP_CHAPTERS,
  DSA_CPP_LESSONS,
  DSA_CPP_TOTAL_XP,
} from "../data/dsaCppCurriculum";
import useDsaCppProgress from "../hooks/useDsaCppProgress";
import LearnChapterPathOverview from "../../shared/LearnChapterPathOverview";
import LearnChapterGrid from "../../shared/LearnChapterGrid";
import CourseCertificate from "../../shared/CourseCertificate";

const BASE_PATH = "/learn/dsa-cpp";

function lessonPlainText(lesson) {
  return lesson.theory
    .filter((block) => block.type === "text" || block.type === "callout")
    .map((block) => block.content.replace(/\*\*/g, "").replace(/`/g, ""))
    .join(" ");
}

export default function DsaHub() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const {
    isAuthenticated,
    completedMap: progress,
    bookmarks,
    lastLessonId,
  } = useDsaCppProgress();

  const completedCount = Object.keys(progress).length;
  const earnedXP = DSA_CPP_LESSONS.filter((l) => progress[l.id]).reduce(
    (s, l) => s + l.xp,
    0,
  );
  const pct = Math.round((completedCount / DSA_CPP_LESSONS.length) * 100) || 0;
  const nextLesson =
    DSA_CPP_LESSONS.find((lesson) => !progress[lesson.id]) || DSA_CPP_LESSONS[0];
  const resumeLesson =
    DSA_CPP_LESSONS.find((lesson) => lesson.id === lastLessonId) || nextLesson;
  const completedChapters = DSA_CPP_CHAPTERS.filter((ch) =>
    ch.lessons.every((lesson) => progress[lesson.id]),
  ).length;
  const bookmarkedLessons = bookmarks
    .map((id) => DSA_CPP_LESSONS.find((lesson) => lesson.id === id))
    .filter(Boolean);

  const filteredLessons = useMemo(() => {
    const query = search.trim().toLowerCase();
    return DSA_CPP_LESSONS.filter((lesson) => {
      const matchesQuery =
        !query ||
        lesson.title.toLowerCase().includes(query) ||
        lesson.chapterTitle.toLowerCase().includes(query) ||
        lessonPlainText(lesson).toLowerCase().includes(query);
      const matchesFilter =
        filter === "all" ||
        (filter === "todo" && !progress[lesson.id]) ||
        (filter === "done" && progress[lesson.id]) ||
        (filter === "bookmarked" && bookmarks.includes(lesson.id));
      return matchesQuery && matchesFilter;
    });
  }, [bookmarks, filter, progress, search]);

  return (
    <div className="oops-hub dsa-hub">
      <div className="oops-hero dsa-hero">
        <Link to="/language/C++" className="oops-back-btn" style={{ marginBottom: "0.75rem", display: "inline-flex" }}>
          ← C++ courses
        </Link>
        <div className="oops-hero-badge">C++ · DSA TRACK</div>
        <h1 className="oops-hero-title">
          Data Structures
          <br />
          <span className="oops-hero-accent">& Algorithms (C++)</span>
        </h1>
        <p className="oops-hero-sub">
          Learn algorithmic thinking, complexity analysis, and implement core data structures in C++ with hands-on problems and challenges.
        </p>

        <div className="oops-hero-grid">
          <div className="oops-xp-bar-wrap">
            <div className="oops-xp-meta">
              <span>
                {isAuthenticated
                  ? `${completedCount}/${DSA_CPP_LESSONS.length} lessons · ${earnedXP}/${DSA_CPP_TOTAL_XP} XP`
                  : `Sign in to track progress · ${DSA_CPP_LESSONS.length} lessons`}
              </span>
              <span>{isAuthenticated ? `${pct}%` : "—"}</span>
            </div>
            <div className="oops-xp-track">
              <div className="oops-xp-fill" style={{ width: isAuthenticated ? `${pct}%` : "0%" }} />
            </div>
          </div>

          {!isAuthenticated && (
            <div className="oops-auth-gate oops-auth-gate-hub">
              <p>
                Create a free account to run C++ challenges, earn XP, and save your place in the DSA course.
              </p>
              <div className="oops-auth-gate-actions">
                <Link to="/login" className="oops-auth-gate-btn">
                  Sign in
                </Link>
                <Link to="/signup" className="oops-auth-gate-btn oops-auth-gate-btn-primary">
                  Sign up
                </Link>
              </div>
            </div>
          )}

          <div className="oops-resume-panel">
            <span className="oops-sync-pill">{isAuthenticated ? "Progress saved to your account" : "Browse lessons — sign in to save progress"}</span>
            <h2>{resumeLesson.title}</h2>
            <p>
              {resumeLesson.chapterTitle} · {resumeLesson.xp} XP
            </p>
            <button type="button" onClick={() => navigate(`${BASE_PATH}/lesson/${resumeLesson.id}`)}>
              {completedCount > 0 ? "Resume DSA" : "Start DSA"}
            </button>
          </div>
        </div>
      </div>

      <div className="oops-guide-tools">
        <div className="oops-tool-panel oops-tool-panel-main">
          <span className="oops-interactive-label">Find a DSA topic</span>
          <div className="oops-search-row">
            <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search arrays, trees, BFS..." aria-label="Search DSA lessons" />
            <div className="oops-filter-tabs" aria-label="Filter DSA lessons">
              {[
                ["all", "All"],
                ["todo", "To do"],
                ["done", "Done"],
                ["bookmarked", "Saved"],
              ].map(([value, label]) => (
                <button key={value} type="button" className={filter === value ? "active" : ""} onClick={() => setFilter(value)}>
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div className="oops-search-results">
            {filteredLessons.slice(0, 6).map((lesson) => (
              <button key={lesson.id} type="button" className="oops-search-result" onClick={() => navigate(`${BASE_PATH}/lesson/${lesson.id}`)}>
                <span>{progress[lesson.id] ? "✓" : "○"}</span>
                <strong>{lesson.title}</strong>
                <small>{lesson.chapterTitle}</small>
              </button>
            ))}
            {filteredLessons.length === 0 && <p className="oops-empty-copy">No lessons match that search.</p>}
          </div>
        </div>

        <div className="oops-tool-panel">
          <span className="oops-interactive-label">Recommended</span>
          <h2>{nextLesson.title}</h2>
          <p>Next in {nextLesson.chapterTitle}. Earn {nextLesson.xp} XP.</p>
          <button type="button" onClick={() => navigate(`${BASE_PATH}/lesson/${nextLesson.id}`)}>Open next lesson</button>
        </div>

        <div className="oops-tool-panel">
          <span className="oops-interactive-label">Bookmarks</span>
          {bookmarkedLessons.length > 0 ? (
            <div className="oops-bookmark-list">
              {bookmarkedLessons.slice(0, 3).map((lesson) => (
                <button key={lesson.id} type="button" onClick={() => navigate(`${BASE_PATH}/lesson/${lesson.id}`)}>
                  <strong>{lesson.title}</strong>
                  <small>{lesson.chapterTitle}</small>
                </button>
              ))}
            </div>
          ) : (
            <p>Bookmark lessons to review them here.</p>
          )}
        </div>
      </div>

      <div className="oops-dashboard-strip">
        <div className="oops-stat-tile">
          <span>Lessons</span>
          <strong>{completedCount}/{DSA_CPP_LESSONS.length}</strong>
        </div>
        <div className="oops-stat-tile">
          <span>Chapters</span>
          <strong>{completedChapters}/{DSA_CPP_CHAPTERS.length}</strong>
        </div>
        <div className="oops-stat-tile">
          <span>Bookmarks</span>
          <strong>{bookmarks.length}</strong>
        </div>
      </div>

      <LearnChapterPathOverview chapters={DSA_CPP_CHAPTERS} progress={progress} onChapterSelect={(chapter) => navigate(`${BASE_PATH}/lesson/${chapter.lessons[0].id}`)} />

      <LearnChapterGrid chapters={DSA_CPP_CHAPTERS} progress={progress} basePath={BASE_PATH} navigate={navigate} />
      <CourseCertificate
        courseName="DSA with C++"
        totalLessons={DSA_CPP_LESSONS.length}
        completedCount={completedCount}
        earnedXP={earnedXP}
        totalXP={DSA_CPP_TOTAL_XP}
      />
    </div>
  );
}
